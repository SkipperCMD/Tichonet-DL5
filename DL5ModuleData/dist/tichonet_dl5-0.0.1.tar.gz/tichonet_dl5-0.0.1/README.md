# Tichonet's DL4 Package which inludes all the functions, classes, DLModel, DLLayer, etc.

**May be used for Deep Learning or Machine Learning, Under the concent / permission of Gad and or the Computer Science Staff at Tichonet**

